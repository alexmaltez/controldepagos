<?php
	$currDir = dirname(__FILE__);
	require("{$currDir}/incCommon.php");

	$GLOBALS['page_title'] = $Translation['server status'];
	include("{$currDir}/incHeader.php");
	include("{$currDir}/incFooter.php");
