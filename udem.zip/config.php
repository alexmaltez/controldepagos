<?php
	$dbServer = 'localhost';
	$dbUsername = 'root';
	$dbPassword = 'yosoyalex';
	$dbDatabase = 'contrasenia';
	$appURI = 'udem';
	$host = 'localhost';

	$adminConfig = array(
		'adminUsername' => "admin",
		'adminPassword' => "\$2y\$10\$HnEtsnbwzRbN8C6Oh9xpQ.E/5Bc7CKnwglr/o1ZMWw0pn4DjCt2Aa",
		'notifyAdminNewMembers' => "0",
		'defaultSignUp' => "0",
		'anonymousGroup' => "temporal",
		'anonymousMember' => "invitado",
		'groupsPerPage' => "10",
		'membersPerPage' => "10",
		'recordsPerPage' => "10",
		'custom1' => "Nombre Completo",
		'custom2' => "Direccion",
		'custom3' => "Ciudad",
		'custom4' => "Estado",
		'MySQLDateFormat' => "%d/%m/%Y",
		'PHPDateFormat' => "j/n/Y",
		'PHPDateTimeFormat' => "d/m/Y, h:i a",
		'senderName' => "",
		'senderEmail' => "alxteam.ni@gmail.com",
		'approvalSubject' => "Su membresía ahora está aprobada",
		'approvalMessage' => "Hola ,\r\nSu membresía ahora está aprobada por el administrador. Puede iniciar sesión en su cuenta aquí:\r\nhttp://localhost/udem/admin\r\n\r\nSaludos,\r\nAdmin",
		'maintenance_mode_message' => "El sistema actualmente se encuentra en Mantenimiento.\r\nEsperamos estar de regreso en un par de horas. Gracias por su paciencia.",
		'mail_function' => "mail",
		'smtp_server' => "",
		'smtp_encryption' => "",
		'smtp_port' => "25",
		'smtp_user' => "",
		'smtp_pass' => ""
	);