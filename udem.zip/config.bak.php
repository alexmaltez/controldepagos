<?php
	$dbServer = 'localhost';
	$dbUsername = 'root';
	$dbPassword = 'yosoyalex';
	$dbDatabase = 'udem';
	$appURI = 'udem';
	$host = 'localhost';

	$adminConfig = array(
		'adminUsername' => "admin",
		'adminPassword' => "\$2y\$10\$cq3xRwiv/8ganpc3e31YgurGQnPvWcJ5D1ITjHVo0KZ.QdJfQUyfW",
		'notifyAdminNewMembers' => "",
		'defaultSignUp' => "0",
		'anonymousGroup' => "temporal",
		'anonymousMember' => "invitado",
		'groupsPerPage' => "10",
		'membersPerPage' => "10",
		'recordsPerPage' => "10",
		'custom1' => "Nombre Completo",
		'custom2' => "Direccion",
		'custom3' => "Ciudad",
		'custom4' => "Estado",
		'MySQLDateFormat' => "%d/%m/%Y",
		'PHPDateFormat' => "j/n/Y",
		'PHPDateTimeFormat' => "d/m/Y, h:i a",
		'senderName' => "Gesti�n de membres�a",
		'senderEmail' => "alexmaltez@hotmail.es",
		'approvalSubject' => "Su membres�a ahora est� aprobada",
		'approvalMessage' => "Hola ,\n\nSu membres�a ahora est� aprobada por el administrador. Puede iniciar sesi�n en su cuenta aqu�:\nhttp://localhost/udem\n\nSaludos,\nAdmin",
		'maintenance_mode_message' => "El sistema actualmente se encuentra en Mantenimiento.\r\nEsperamos estar de regreso en un par de horas. Gracias por su paciencia.",
		'mail_function' => "mail",
		'smtp_server' => "",
		'smtp_encryption' => "",
		'smtp_port' => "25",
		'smtp_user' => "",
		'smtp_pass' => ""
	);